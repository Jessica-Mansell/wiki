#troll

hides under bridges